import { Component, OnInit } from "@angular/core";

@Component({
  selector: "app-distinct-com",
  templateUrl: "./distinct.component.html",
  styleUrls: ["distinct.component.css"]
})
export class SeparatorBarComponent implements OnInit {
  constructor() {}

  ngOnInit() {}
}
